from django.contrib import admin
from .models import Verifiaction, ForgotPassword

# Register your models here.
admin.site.register(Verifiaction)
admin.site.register(ForgotPassword)
